package com.tasksapp.computeprojectdigest;

/**
 *
 * @author Fred x19365173, Lorcan x18345853, Felipe x18336023
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.security.*;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/*
reference for this code, week 6 lab
https://mymoodle.ncirl.ie/pluginfile.php/209521/mod_resource/content/1/ComputeMessageDigest.java
 */
public class ComputeProjectDigest {

    public static void main(String[] args) {

//hash encryption and md5
        MessageDigest shaMethod = null; //declares a new object of MessageDigest
        Scanner userIn = new Scanner(System.in); //declares a new scanner called userIn to take user input
        try {
            shaMethod = MessageDigest.getInstance("SHA-1");
        } catch (NoSuchAlgorithmException e) {
            System.out.println("No such algorithm");
        }
        //this try and catch method is used to catch a no algorithm exception and to use the getInstance() method on our Message digest through the SHA-1 method
        System.out.println("Algorithm type: " + shaMethod.getAlgorithm());//grabs our instance and tells the program to use getALgoritm which we declared as SHA-1 and print it
        System.out.println("Type a message to hash encrypt");//prints a simple message to the user
        String s = userIn.nextLine();//sets up a new string to take some user input using the scanner userIn
        byte bSetOne[] = s.getBytes();//creates a new Byte array and tells it to take the user input from userIn and break in to bytes via getBytes() method
        byte[] hash = shaMethod.digest(bSetOne);//makes a new byte array telling the program to use the digest() method on our byte array bSetOne
        System.out.println("Algorithm type: " + shaMethod.getAlgorithm());//grabs our instance and tells the program to use getALgoritm which we declared as SHA-1 and print it
        System.out.println("Hash of '" + s + "' using SHA-1 algorithm is :: ");//prints a message to the user

        for (byte i : hash) {
            System.out.print(i + " "); //a loop used to print our hashed message
        }
        System.out.println("\n");//line skip to make it look neat
        try {
            shaMethod = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            System.out.println("No such algorithm");
        }
        //this try and catch method is used to catch a no algorithm exception and to use the getInstance() method on our Message digest through the MD5 method
        System.out.println("Algorithm: " + shaMethod.getAlgorithm());//grabs our instance and tells the program to use getALgoritm which we declared as MD5 and print it
        byte[] hash1 = shaMethod.digest(bSetOne);//makes a new byte array telling the program to use the digest() method on our byte array bSetOne however this time using MD5
        System.out.println("Hash of '" + s + "' using MD5 is : ");
        for (byte o : hash1) {
            System.out.print(o + " ");//a loop used to print our hashed message
        }
        System.out.println("\n");//line skip to make it look neat

//keypairs, keytools, key storage encryption
        try {
            KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");//declares a new KepPairGenerator called gen
            gen.initialize(2048);//tells gen to initiralize at 2048
            KeyPair kp1 = gen.generateKeyPair();//generates a new KeyPair
            PrivateKey privateKey = kp1.getPrivate();//The public key is used to encrypt messages 
            PublicKey publicKey = kp1.getPublic();//the private key is used to decrypt messages

            try (FileOutputStream fos = new FileOutputStream("public.key")) {//FileOutputStream is an outputstream for writing data streams of bytes that are raw to files or in this case store data in a file
                fos.write(publicKey.getEncoded());//serialization function to encoded our data
            } catch (IOException e) {
                System.out.println("Error input exception");
            }
            //try catch for catching any I/O exceptions
            File publicKeyFile = new File("public.key");//declares a new file
            byte[] publicKeyBytes = Files.readAllBytes(publicKeyFile.toPath());//tells the bytes to be stored in our new files
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);//Creates a new X509EncodedKeySpec with the given encoded key.
            keyFactory.generatePublic(publicKeySpec);
            System.out.println("Insert more text to encrypt this time with KeyPairing as well as KeyTools and KeyStorage");
            String secretMessage = userIn.nextLine();//declares a new scanner 

            Cipher encryptCipher = Cipher.getInstance("RSA");//creates a cipher object using the Rivest–Shamir–Adleman algorithm
            encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);//encrypts the public key

            byte[] secretMessageBytes = secretMessage.getBytes(StandardCharsets.UTF_8);//byte array secretmessage
            byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessageBytes);//the last(final) step to calculate the result, and there is no more data to be inputted 

            String encodedMessage = Base64.getEncoder().encodeToString(encryptedMessageBytes);//Base 64 is an encoding scheme that converts binary data into text format to make it more readable
            System.out.print("\n This is the encrypted message: " + "\n" + encodedMessage + "\n");//prints encrypted message
            Cipher decryptCipher = Cipher.getInstance("RSA");//decrypt cipher declaration used
            decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);//decrypts the data using the private key
            byte[] decryptedMessageBytes = decryptCipher.doFinal(encryptedMessageBytes);//tells the byte array there is no more data to be inputted
            String decryptedMessage = new String(decryptedMessageBytes, StandardCharsets.UTF_8);//tells the string to use the decrypted message array and put it into standard character sets
            System.out.print("\n" + "This is the decrypted message: " + "\n" + decryptedMessage + "\n");//prints decrypted message
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Error no such algorithm");
        } catch (IOException f) {
            System.out.println("Error no such input");
        } catch (InvalidKeySpecException g) {
            System.out.println("Error no such key");
        } catch (NoSuchPaddingException h) {
            System.out.println("Error no such padding");
        } catch (IllegalBlockSizeException i) {
            System.out.println("Error block size doesnt exist");
        } catch (BadPaddingException j) {
            System.out.println("Error bad padding");
        } catch (InvalidKeyException k) {
            System.out.println("Error no such key");
        }
//catches all of the exceptions that needed to be declared

//mac encryption     
        try {
            Mac mac = Mac.getInstance("HmacSHA256");//declares a mac object using the HmacSHA256 method

            byte[] keyBytes = new byte[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; //declares a raw byte array which we will use as our raw bytes
            String algorithm = "RawBytes";//simple string to store rawBytes 
            SecretKeySpec key2 = new SecretKeySpec(keyBytes, algorithm);//secret key object
            mac.init(key2);//initalizes the mac

            Scanner attemptMac = new Scanner(System.in);//simple scanner
            System.out.println("\n" + "Enter text for your first data set for MAC Encryption");
            String ogData = attemptMac.nextLine();//creates an original data set 1
            System.out.println("\n" + "Enter text for your second data set for MAC Encryption");
            String ogData2 = attemptMac.nextLine();//creates an original data set 2

            byte[] data = ogData.getBytes("UTF-8");//byte array data uses original data 1 and turns it into bytes using getBytes("UTF-8")
            byte[] data2 = ogData2.getBytes("UTF-8");//byte array data2 uses original data 2 and turns it into bytes using getBytes("UTF-8")
            mac.update(data);//updates data (set 1)
            mac.update(data2);//updates data (set 2)
            //updates the byte arrays 
            byte[] macB = mac.doFinal(data);//new byte array stating there is no more data, using data set 1
            byte[] macB2 = mac.doFinal(data2);//new byte array stating there is no more data, using data set 2
            System.out.println("\n");
            System.out.println("Lets encrypt two sets of data using MAC");
            System.out.println("This is the first set: \n" + ogData);
            System.out.println("This is the second set: \n" + ogData2 + "\n");

            System.out.println("Lets Encrypt this data now!");
            System.out.println("Heres the first data set: \n" + data);
            System.out.println(macB);//prints encrypted data set 1
            System.out.println("Heres the second data set: \n" + data2);
            System.out.println(macB2);//prints encrypted data set 2

            System.out.println("Here is the first original set of words decrypted: ");
            String oriText = new String(data, StandardCharsets.UTF_8);
            System.out.println(oriText);

            System.out.println("Here is the secind original set of words decrypted: ");
            String oriText2 = new String(data2, StandardCharsets.UTF_8);
            System.out.println(oriText2);

        } catch (NoSuchAlgorithmException l) {
            System.out.println("Error no such algorithm!");
        } catch (InvalidKeyException m) {
            System.out.println("Error invalid key!");
        } catch (UnsupportedEncodingException n) {
            System.out.println("Error unsupported encoding exception");
        }
        //catches all possible exceptions
        
//signature example using keypairs also
        try {
            SecureRandom secureRandom = new SecureRandom();//uses SecureRandom to make a new object
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("DSA");//makes a keypair instance using the DSA class
            KeyPair kpNew = keyPairGenerator.generateKeyPair();
            Signature sig = Signature.getInstance("SHA256WithDSA");//makes a signature instance using the SSHA256WithDSA class
            sig.initSign(kpNew.getPrivate(), secureRandom);
            Scanner felipeYe = new Scanner(System.in);//scanner
            System.out.println("\n" + "Print a signature");
            String felipeInput = felipeYe.nextLine();//takes user input
            byte[] inputArrayOfBytes = felipeInput.getBytes("UTF-8");//byte array 
            sig.update(inputArrayOfBytes);//update byte array
            byte[] digiSig = sig.sign();//finish signature operation
            Signature sig2 = Signature.getInstance("SHA256WithDSA");//makes another signature object which we will use for verifying
            sig2.initVerify(kpNew.getPublic());//take the encrypted data
            sig2.update(inputArrayOfBytes);//update signature 2
            boolean verified = sig2.verify(digiSig);//a boolean that becomes true when digiSig matches sig2
            System.out.println("verified = " + verified);
        } catch (InvalidKeyException o) {
            System.out.println("Error invalid key!");
        } catch (NoSuchAlgorithmException p) {
            System.out.println("Error no such algorithm!");
        } catch (UnsupportedEncodingException q) {
            System.out.println("Error unsupported coding exception!");
        } catch (SignatureException r) {
            System.out.println("Error signature exception!");
        }
        //catches all possible exceptions
    }
}
